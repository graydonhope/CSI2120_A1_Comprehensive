package main

import (
	"fmt"
	"os"
	"encoding/csv"
	"io"
	"stable_matching/person"
	"sync"
	"strconv"
)

var studentIndices map[string]int
var employerIndices map[string]int
var employerList []person.Employer
var studentList []person.Student
var matches map[string]string
var mutex sync.RWMutex

func main() {
	for k := 0; k < 30; k++ {
		if len(os.Args) == 3 {
			employerPath := os.Args[1]
			studentPath := os.Args[2]
			employers := readCSVFile(employerPath)
			students := readCSVFile(studentPath)
			employerList = configureEmployers(employers)
			studentList = configureStudents(students)
			mutex = sync.RWMutex{}
			waitGroup := &sync.WaitGroup{}
			matches = make(map[string]string)
			waitGroup.Add(len(employerList))
	
			for i := 0; i < len(employerList); i++ {
				go func (employer person.Employer, i int) {
					offer(employer, waitGroup, false)
				} (employerList[i], i)	
			}
	
			waitGroup.Wait()
			writeToCSV(matches, len(employerList))
					
		} else {
			fmt.Println("CSI 2110 : Invalid input. Please include two filenames (employer and student)")
		}
	}	
}

func writeToCSV(pairs map[string]string, n int) {
	dimension := strconv.Itoa(n)
	filename := "matches_go_" + dimension + "x" + dimension + ".csv"
	file, err := os.Create(filename)
	defer file.Close()
	if err != nil {
		panic(err)
	}

	writer := csv.NewWriter(file)
	defer writer.Flush()
	colNames := []string{"Employer", "Student"}
	colErr := writer.Write(colNames)
	if colErr != nil {
		fmt.Println("CSI2110", err)
	}

	for k, v := range matches {
		data := []string{v,k}
		err := writer.Write(data)

		if err != nil {
			fmt.Println("CSI2110", err)
		}
	}
}

func offer(employer person.Employer, wg *sync.WaitGroup, recur bool) {
	if !recur {
		defer wg.Done()
	}
	if !person.GetMatched(employer) {
		mostPreferredStudentName := person.GetMostPreferred(employer)
		if mostPreferredStudentName != "" {
			mutex.Lock()
			student := studentList[studentIndices[mostPreferredStudentName]]
			mutex.Unlock()
			evaluate(employer, student, wg)
		}
		return 
	} 
}

func evaluate(employer person.Employer, student person.Student, wg *sync.WaitGroup) {
	if !person.IsStudentMatched(student) {
		mutex.Lock()
		// Add (employer, student) pair to matches set		
		matches[student.Name] = employer.Name
		employer.IsMatched = true
		student.IsMatched = true
		student.Employer = employer.Name
		studentList[studentIndices[student.Name]] = student
		employerList[employerIndices[employer.Name]] = employer
		mutex.Unlock()

	} else if person.Prefers(student.Employer, employer.Name, student) {
		mutex.Lock()
		// Replace (oldEmployer, student) match with pair (employer, student) 
		oldEmployer := student.Employer		
		matches[student.Name] = employer.Name
		student.IsMatched = true
		student.Employer = employer.Name
		employer.IsMatched = true
		studentList[studentIndices[student.Name]] = student
		employerList[employerIndices[employer.Name]] = employer

		if oldEmployer != "" {
			employerObject := employerList[employerIndices[oldEmployer]]
			employerObject.IsMatched = false
			employerList[employerIndices[employerObject.Name]] = employerObject
			mutex.Unlock()

			offer(employerObject, wg, true)
		}
	} else {
		// Student rejects the offer. Set offered Job to yes
		mutex.Lock()
		person.SetJobOffered(employer, student.Name, true)
		employerList[employerIndices[employer.Name]] = employer
		mutex.Unlock()
		
		offer(employer, wg, true)
	}
}

func configureEmployers(employers [][]string) []person.Employer {
	employerList := []person.Employer{}
	 
	employerIndices = make(map[string]int)
	 

	for i := 0; i < len(employers); i++ {
		name := employers[i][0]
		preferences := []string{}
		for j := 1; j < len(employers[i]); j++ {
			preferences = append(preferences, employers[i][j])
		}

		newEmployer := person.NewEmployer(name, preferences, false)
		employerList = append(employerList, newEmployer)
		mutex.Lock()
		employerIndices[name] = i
		mutex.Unlock()
	}

	return employerList
}

func configureStudents(students [][]string) []person.Student {
	studentList := []person.Student{}
	studentIndices = make(map[string]int)

	for i := 0; i < len(students); i++ {
		name := students[i][0]
		preferences := []string{}
		for j := 1; j < len(students[i]); j++ {
			preferences = append(preferences, students[i][j])
		}

		newStudent := person.NewStudent(name, preferences, false, "")
		studentList = append(studentList, newStudent)
		
		mutex.Lock()
		studentIndices[name] = i
		mutex.Unlock()
		 
	}

	return studentList
}


func readCSVFile(path string) [][]string {
	file, _ := os.Open(path)
	reader := csv.NewReader(file)
	input := [][]string{}
	
	for {
		record, err := reader.Read()

		if err == io.EOF {
			break
		}

		if err != nil {
			fmt.Println("CSI2110")
			panic(err)
		}

		input = append(input, record)
	}

	return input
}