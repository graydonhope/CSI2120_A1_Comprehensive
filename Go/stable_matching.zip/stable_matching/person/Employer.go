package person

import "fmt"

// Employer struct with name and preferences
type Employer struct {
	Name string
	ListOfPreferences []string
	IsMatched bool
	OfferedJob map[string]bool
}

// NewEmployer returns a new employer with a name and list of preferences 
func NewEmployer(name string, preferences []string, isMatched bool) Employer {
	offeredJob := make(map[string]bool)

	for i := 0; i < len(preferences); i++ {
		offeredJob[preferences[i]] = false
	}

	employer := Employer{name, preferences, isMatched, offeredJob}

	return employer
}

// SetMatched is a set function for the isMatched bool
func SetMatched(employer Employer, isMatched bool) {
	employer.IsMatched = isMatched
}

func GetMatched(employer Employer) bool {
	return employer.IsMatched
}

// OfferedJob returns a boolean value of whether the student has received a job offer or not.
func OfferedJob(employer Employer, studentName string) bool {
	return employer.OfferedJob[studentName]
}

func SetJobOffered(employer Employer, studentName string, offered bool) {
	employer.OfferedJob[studentName] = offered
}

func GetPreferences(employer Employer) []string {
	return employer.ListOfPreferences
}

func GetMostPreferred(employer Employer) string {
	preferences := employer.ListOfPreferences

	for i := 0; i < len(preferences); i++ {
		name := preferences[i]
		if employer.OfferedJob[name] == false {
			return preferences[i]
		}
	}

	fmt.Println("Employer offered to everyone - not good !.!.!.!.!.!")
	return ""
}