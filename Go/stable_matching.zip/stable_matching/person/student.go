package person

// Student struct with name and preferences
type Student struct {
	Name string
	ListOfPreferences []string
	IsMatched bool
	Rankings map[string]int
	Employer string
}

// NewStudent returns a student with a name and list of preferences 
func NewStudent(name string, preferences []string, isMatched bool, employer string) Student {
	rankings := make(map[string]int)

	for i := 0; i < len(preferences); i++ {
		rankings[preferences[i]] = i
	}

	student := Student{name, preferences, isMatched, rankings, employer}

	return student
}

// Prefers returns true if the student prefers the new employer more than the existing employer.
func Prefers(oldEmployer string, newEmployer string, student Student) bool {
	if student.Rankings[oldEmployer] > student.Rankings[newEmployer] {
		return true
	} 
	
	return false
}

func SetStudentMatched(student Student) {
	student.IsMatched = true
}

func GetCurrentEmployer(student Student) string {
	return student.Employer
}

func IsStudentMatched(student Student) bool {
	return student.IsMatched
}